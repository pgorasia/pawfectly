-- Migration: Update constraint to allow simple string IDs
-- NOTE: This migration is superseded by 014_change_dog_id_to_text.sql
-- Run migration 014 instead, which changes the column type from UUID to TEXT
-- 
-- This file is kept for reference but should not be run separately.

