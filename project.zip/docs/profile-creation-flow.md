# Profile Creation Details

Dog Profile:
- Name
- Age group
- Breed (searchable dropdown)
- Size
- Energy level
- Play styles (multi-select)
- Temperament (optional)

Multiple dogs allowed.

Human Profile:
- Name
- DOB
- Gender:
  - Male
  - Female
  - Trans
  - Non-binary
  - Self-described
  - Prefer not to say

Photos:
- Photos are grouped by:
  - Each dog
  - Human
- AI may auto-detect dog vs human
- User can confirm or reassign photos
- Dog-only photos are allowed
- Human-dog together photo is encouraged
- AI to auto-detect atleast one photo has human
