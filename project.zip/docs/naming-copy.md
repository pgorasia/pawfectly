# Naming & Copy Guidelines

Connection Types:

🐾 Pawsome Pals
"Let your dog lead the way to new friends"

💛 Pawfect Match
"Find someone who loves your dog as much as you do"

Tone:
- Friendly
- Clear
- Dog-first
- No sexualized or explicit language

Avoid:
- Dating app clichés
- “Swipe culture” language
- Pressure-heavy wording
