# Onboarding Flow (High-Level)

1. Welcome screen
2. Dog details (repeatable — can add multiple dogs)
3. Human details
4. Photo upload (dogs + human, all in one flow)
5. Location setup
6. Connection style selection
   - Pawsome Pals
   - Pawfect Match
   - Or both
7. Preferences (gender, age, distance as filters)
8. Go directly to feed 

Rules:
- Dog info always comes before human intent
