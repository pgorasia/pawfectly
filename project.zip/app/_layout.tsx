import { Stack, useRouter } from "expo-router";
import { useEffect, useRef } from "react";
import { Platform, View } from "react-native";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider, useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import * as NavigationBar from "expo-navigation-bar";
import { AuthProvider } from "@/contexts/AuthContext";
import { AuthSessionStoreProvider } from "@/contexts/AuthSessionStore";
import { MeProvider } from "@/contexts/MeContext";
import { ProfileDraftProvider } from "@/hooks/useProfileDraft";
import { MeBootstrapper } from "@/components/common/MeBootstrapper";
import { DraftBootstrapper } from "@/components/common/DraftBootstrapper";
import { AuthSessionSync } from "@/components/common/AuthSessionSync";
import { setupNotificationHandler } from "@/services/notifications/photoNotifications";
import * as Notifications from "expo-notifications";
import { Colors } from "@/constants/colors";

function NotificationHandler() {
  const router = useRouter();

  useEffect(() => {
    const subscription = setupNotificationHandler((data) => {
      if (data.type === "photo_rejected" && data.screen) {
        router.push(data.screen as any);
      }
    });

    const foregroundSubscription = Notifications.addNotificationReceivedListener(
      (notification) => {
        console.log("[RootLayout] Notification received:", notification);
      }
    );

    return () => {
      subscription.remove();
      foregroundSubscription.remove();
    };
  }, [router]);

  return null;
}

export default function RootLayout() {
  useEffect(() => {
    // Android navigation bar: keep it visible and styled consistently.
    // We render an in-app "letterbox" spacer (black) for the navigation buttons area.
    if (Platform.OS === "android") {
      NavigationBar.setPositionAsync("absolute").catch(() => undefined);
      NavigationBar.setBackgroundColorAsync("#000000").catch(() => undefined);
      NavigationBar.setBorderColorAsync("#000000").catch(() => undefined);
      NavigationBar.setButtonStyleAsync("light").catch(() => undefined);
    }
  }, []);

  function AppFrame() {
    const insets = useSafeAreaInsets();

    // On Android, the bottom inset (navigation buttons area) can temporarily
    // collapse to 0 when the keyboard opens, depending on device/ROM.
    // We keep a stable maximum so UI never "drops" behind the keyboard.
    const stableAndroidNavInset = useRef(0);
    if (Platform.OS === "android") {
      stableAndroidNavInset.current = Math.max(stableAndroidNavInset.current, Math.max(insets.bottom, 0));
    }

    // For Android 3-button/gesture navigation, keep a consistent black "base" under the app.
    // This spacer ensures no screen renders behind the system nav buttons.
    const androidNavSpacer = Platform.OS === "android" ? stableAndroidNavInset.current : 0;

    return (
      <View style={{ flex: 1, backgroundColor: Platform.OS === "android" ? "#000" : Colors.background }}>
        <View style={{ flex: 1, backgroundColor: Colors.background }}>
          <AuthSessionStoreProvider>
            <AuthProvider>
              <AuthSessionSync />
              <MeProvider>
                <ProfileDraftProvider>
                  <MeBootstrapper />
                  <DraftBootstrapper />
                  <NotificationHandler />
                  <Stack screenOptions={{ headerShown: false }} />
                </ProfileDraftProvider>
              </MeProvider>
            </AuthProvider>
          </AuthSessionStoreProvider>
        </View>

        {androidNavSpacer > 0 ? <View style={{ height: androidNavSpacer, backgroundColor: "#000" }} /> : null}
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar style="dark" />
        <AppFrame />
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
