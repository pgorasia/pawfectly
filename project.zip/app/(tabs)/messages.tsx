/**
 * Messages Screen - Complete Implementation
 * Features:
 * - Top lane filter (All/Pals/Match) that filters everything
 * - Matches carousel + "Liked You" card (always shown if liked_you_count > 0)
 * - Messages tab with active threads
 * - Requests tab with Received/Sent sub-tabs (shown when both exist)
 * - Client-side filtering (no network calls on filter change)
 * - SWR-like caching with useRef
 * - Pull-to-refresh
 * - Error handling with non-blocking banner
 */

import React, { useState, useCallback, useRef, useEffect } from 'react';
import {
  View,
  StyleSheet,
  ScrollView,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useRouter, useFocusEffect } from 'expo-router';
import { ScreenContainer } from '@/components/common/ScreenContainer';
import { AppText } from '@/components/ui/AppText';
import { MatchTile } from '@/components/messages/MatchTile';
import { MessageRow } from '@/components/messages/MessageRow';
import { RequestRow } from '@/components/messages/RequestRow';
import { SentRequestTile } from '@/components/messages/SentRequestTile';
import { LikedYouPlaceholder } from '@/components/messages/LikedYouPlaceholder';
import {
  getMessagesHome,
  getIncomingRequests,
  getOrCreateConversation,
  type MessagesHomeResponse,
  type IncomingRequest,
  type Lane,
  type Match,
  type Thread,
  type SentRequest,
} from '@/services/messages/messagesService';
import { Colors } from '@/constants/colors';
import { Spacing } from '@/constants/spacing';
import { chatEvents, CHAT_EVENTS, type FirstMessageSentData } from '@/utils/chatEvents';
import { truncatePreview } from '@/utils/chatHelpers';

type LaneFilter = 'all' | 'pals' | 'match';
type TabType = 'messages' | 'requests';
type RequestsSubTab = 'received' | 'sent';

interface CachedData {
  messagesHome: MessagesHomeResponse | null;
  incomingRequests: IncomingRequest[];
  timestamp: number;
}

export default function MessagesScreen() {
  const router = useRouter();

  // Top-level lane filter
  const [laneFilter, setLaneFilter] = useState<LaneFilter>('all');

  // Tab state
  const [activeTab, setActiveTab] = useState<TabType>('messages');
  const [requestsSubTab, setRequestsSubTab] = useState<RequestsSubTab>('received');

  // Data state
  const [messagesHome, setMessagesHome] = useState<MessagesHomeResponse | null>(null);
  const [incomingRequests, setIncomingRequests] = useState<IncomingRequest[]>([]);

  // Loading and error state
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Cache with useRef for stale-while-revalidate pattern
  const cacheRef = useRef<CachedData>({
    messagesHome: null,
    incomingRequests: [],
    timestamp: 0,
  });

  /**
   * Load data from server
   * Uses cache to show stale data immediately, then fetches fresh data
   */
  const loadData = useCallback(async (showLoadingSpinner = true) => {
    try {
      // Show cached data immediately if available
      const cache = cacheRef.current;
      const cacheAge = Date.now() - cache.timestamp;
      if (cache.messagesHome && cacheAge < 60000) {
        // Cache is less than 1 minute old
        setMessagesHome(cache.messagesHome);
        setIncomingRequests(cache.incomingRequests);
        setLoading(false);
      }

      if (showLoadingSpinner && !cache.messagesHome) {
        setLoading(true);
      }
      setError(null);

      // Fetch fresh data in parallel
      const [homeData, requestsData] = await Promise.all([
        getMessagesHome().catch((err) => {
          console.error('[MessagesScreen] getMessagesHome failed:', err);
          return null;
        }),
        getIncomingRequests().catch((err) => {
          console.error('[MessagesScreen] getIncomingRequests failed:', err);
          return [];
        }),
      ]);

      // Update state with fresh data
      if (homeData) {
        setMessagesHome(homeData);
        cacheRef.current.messagesHome = homeData;
      }

      setIncomingRequests(requestsData);
      cacheRef.current.incomingRequests = requestsData;
      cacheRef.current.timestamp = Date.now();

      setLoading(false);
      setRefreshing(false);
    } catch (err) {
      console.error('[MessagesScreen] loadData exception:', err);
      setError('Failed to load messages. Pull to refresh.');
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  // Load data on screen focus
  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData])
  );

  /**
   * Listen for first message events from chat screen
   * Move conversation from Matches to Messages optimistically
   */
  useEffect(() => {
    const handleFirstMessage = (data: FirstMessageSentData) => {
      console.log('[MessagesScreen] First message sent:', data);

      setMessagesHome(prev => {
        if (!prev) return prev;

        // Find the match by conversation_id first, then by user_id as fallback
        let matchIndex = prev.matches.findIndex(m => 
          m.conversation_id && m.conversation_id === data.conversationId
        );
        
        // If not found by conversation_id, try by peerUserId
        if (matchIndex === -1 && data.peerUserId) {
          matchIndex = prev.matches.findIndex(m => m.user_id === data.peerUserId);
        }

        if (matchIndex === -1) {
          console.log('[MessagesScreen] Match not found for conversation:', data.conversationId);
          return prev;
        }

        const match = prev.matches[matchIndex];

        // Create a new thread from the match
        const newThread: Thread = {
          conversation_id: data.conversationId, // Use the real conversation_id from DB
          user_id: match.user_id,
          lane: match.lane,
          last_message_at: data.sentAt,
          preview: truncatePreview(data.messageText),
          unread_count: 0, // We sent it
          display_name: match.display_name,
          dog_name: match.dog_name,
          hero_storage_path: match.hero_storage_path,
        };

        // Remove from matches, add to threads
        const newMatches = [...prev.matches];
        newMatches.splice(matchIndex, 1);

        const newThreads = [newThread, ...prev.threads]; // Add to top

        return {
          ...prev,
          matches: newMatches,
          threads: newThreads,
        };
      });

      // Switch to Messages tab to show the new thread
      setActiveTab('messages');
    };

    chatEvents.on(CHAT_EVENTS.FIRST_MESSAGE_SENT, handleFirstMessage);

    return () => {
      chatEvents.off(CHAT_EVENTS.FIRST_MESSAGE_SENT, handleFirstMessage);
    };
  }, []);

  // Pull-to-refresh handler
  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    loadData(false);
  }, [loadData]);

  /**
   * Client-side filtering functions
   * No network calls - filters cached data only
   */
  const filterByLane = <T extends { lane: Lane }>(items: T[]): T[] => {
    if (laneFilter === 'all') return items;
    return items.filter((item) => item.lane === laneFilter);
  };

  // Filtered data
  const filteredMatches = messagesHome ? filterByLane(messagesHome.matches) : [];
  const filteredThreads = messagesHome ? filterByLane(messagesHome.threads) : [];
  const filteredSentRequests = messagesHome ? filterByLane(messagesHome.sent_requests) : [];
  const filteredIncomingRequests = filterByLane(incomingRequests);

  // Compute counts for badges
  const totalUnreadCount = filteredThreads.reduce((sum, t) => sum + (t.unread_count || 0), 0);
  const incomingRequestsCount = filteredIncomingRequests.length;

  /**
   * Navigation handlers
   */
  const handleMatchPress = async (match: Match) => {
    try {
      console.log('[MessagesScreen] Match pressed:', {
        user_id: match.user_id,
        conversation_id: match.conversation_id,
        display_name: match.display_name,
      });

      // Always get or create conversation first to ensure we have a valid UUID
      const conversationId = await getOrCreateConversation(match.user_id, match.lane);

      // Navigate to chat with the real conversation UUID
      router.push({
        pathname: '/messages/[conversationId]',
        params: {
          conversationId, // Always a real UUID
          peerUserId: match.user_id,
          peerName: match.display_name,
          peerPhotoPath: match.hero_storage_path || '',
          peerLane: match.lane,
          isNewConversation: 'true',
        },
      });
    } catch (error) {
      console.error('[MessagesScreen] Failed to open conversation:', error);
      Alert.alert('Error', 'Failed to open conversation. Please try again.');
    }
  };

  const handleThreadPress = (conversationId: string) => {
    router.push(`/messages/${conversationId}`);
  };

  const handleRequestPress = (conversationId: string) => {
    router.push(`/messages/request/${conversationId}`);
  };

  const handleLikedYouPress = () => {
    // Navigate to Liked You tab
    router.push('/liked-you');
  };

  /**
   * Segmented control for lane filter
   */
  const renderLaneFilter = () => (
    <View style={styles.laneFilterContainer}>
      <TouchableOpacity
        style={[styles.laneFilterButton, laneFilter === 'all' && styles.laneFilterButtonActive]}
        onPress={() => setLaneFilter('all')}
        activeOpacity={0.7}
      >
        <AppText
          variant="body"
          style={[styles.laneFilterText, laneFilter === 'all' && styles.laneFilterTextActive]}
        >
          All
        </AppText>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.laneFilterButton, laneFilter === 'pals' && styles.laneFilterButtonActive]}
        onPress={() => setLaneFilter('pals')}
        activeOpacity={0.7}
      >
        <AppText
          variant="body"
          style={[styles.laneFilterText, laneFilter === 'pals' && styles.laneFilterTextActive]}
        >
          Pals
        </AppText>
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.laneFilterButton, laneFilter === 'match' && styles.laneFilterButtonActive]}
        onPress={() => setLaneFilter('match')}
        activeOpacity={0.7}
      >
        <AppText
          variant="body"
          style={[styles.laneFilterText, laneFilter === 'match' && styles.laneFilterTextActive]}
        >
          Match
        </AppText>
      </TouchableOpacity>
    </View>
  );

  /**
   * Matches section (horizontal carousel + liked you card)
   * Always show "X people want to connect" card if liked_you_count > 0
   */
  const renderMatchesSection = () => {
    const hasMatches = filteredMatches.length > 0;
    const hasLikedYou = messagesHome && messagesHome.liked_you_count > 0;

    // Don't render section if nothing to show
    if (!hasMatches && !hasLikedYou) {
      return null;
    }

    return (
      <View style={styles.section}>
        {/* Always show liked you card if count > 0 */}
        {hasLikedYou && (
          <LikedYouPlaceholder
            count={messagesHome.liked_you_count}
            onPress={handleLikedYouPress}
          />
        )}

        {/* Show matches carousel if there are matches */}
        {hasMatches && (
          <>
            <AppText variant="body" style={styles.sectionTitle}>
              Matches
            </AppText>
            <FlatList
              horizontal
              data={filteredMatches}
              keyExtractor={(item) => item.user_id}
              renderItem={({ item }) => (
                <MatchTile match={item} onPress={() => handleMatchPress(item)} />
              )}
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.matchesContent}
            />
          </>
        )}
      </View>
    );
  };

  /**
   * Requests sub-tabs (Received / Sent)
   * Only show tabs if both have entries
   */
  const renderRequestsSubTabs = () => {
    const hasReceived = filteredIncomingRequests.length > 0;
    const hasSent = filteredSentRequests.length > 0;

    // Don't show tabs if only one type exists
    if (!hasReceived || !hasSent) {
      return null;
    }

    return (
      <View style={styles.subTabsContainer}>
        <TouchableOpacity
          style={[styles.subTab, requestsSubTab === 'received' && styles.subTabActive]}
          onPress={() => setRequestsSubTab('received')}
          activeOpacity={0.7}
        >
          <AppText
            variant="caption"
            style={[styles.subTabText, requestsSubTab === 'received' && styles.subTabTextActive]}
          >
            Received ({filteredIncomingRequests.length})
          </AppText>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.subTab, requestsSubTab === 'sent' && styles.subTabActive]}
          onPress={() => setRequestsSubTab('sent')}
          activeOpacity={0.7}
        >
          <AppText
            variant="caption"
            style={[styles.subTabText, requestsSubTab === 'sent' && styles.subTabTextActive]}
          >
            Sent ({filteredSentRequests.length})
          </AppText>
        </TouchableOpacity>
      </View>
    );
  };

  /**
   * Messages/Requests tabs
   */
  const renderTabs = () => (
    <View style={styles.tabsContainer}>
      <TouchableOpacity
        style={[styles.tab, activeTab === 'messages' && styles.tabActive]}
        onPress={() => setActiveTab('messages')}
        activeOpacity={0.7}
      >
        <AppText variant="body" style={[styles.tabText, activeTab === 'messages' && styles.tabTextActive]}>
          Messages
        </AppText>
        {totalUnreadCount > 0 && (
          <View style={styles.badge}>
            <AppText variant="caption" style={styles.badgeText}>
              {totalUnreadCount}
            </AppText>
          </View>
        )}
      </TouchableOpacity>
      <TouchableOpacity
        style={[styles.tab, activeTab === 'requests' && styles.tabActive]}
        onPress={() => setActiveTab('requests')}
        activeOpacity={0.7}
      >
        <AppText variant="body" style={[styles.tabText, activeTab === 'requests' && styles.tabTextActive]}>
          {incomingRequestsCount > 0 ? `${incomingRequestsCount} Requests` : 'Requests'}
        </AppText>
      </TouchableOpacity>
    </View>
  );

  /**
   * Messages tab content
   */
  const renderMessagesContent = () => {
    if (filteredThreads.length === 0) {
      return (
        <View style={styles.emptyState}>
          <AppText variant="body" style={styles.emptyStateText}>
            No messages yet
          </AppText>
          <AppText variant="caption" style={styles.emptyStateSubtext}>
            {laneFilter === 'all'
              ? 'Start chatting with your matches!'
              : `No ${laneFilter === 'pals' ? 'Pals' : 'Match'} messages`}
          </AppText>
        </View>
      );
    }

    return (
      <FlatList
        data={filteredThreads}
        keyExtractor={(item) => item.conversation_id}
        renderItem={({ item }) => (
          <MessageRow thread={item} onPress={() => handleThreadPress(item.conversation_id)} />
        )}
        scrollEnabled={false}
      />
    );
  };

  /**
   * Requests tab content (with Received/Sent sub-tabs)
   */
  const renderRequestsContent = () => {
    const hasReceived = filteredIncomingRequests.length > 0;
    const hasSent = filteredSentRequests.length > 0;

    // If neither, show empty state
    if (!hasReceived && !hasSent) {
      return (
        <View style={styles.emptyState}>
          <AppText variant="body" style={styles.emptyStateText}>
            No requests
          </AppText>
          <AppText variant="caption" style={styles.emptyStateSubtext}>
            {laneFilter === 'all'
              ? 'New connection requests will appear here'
              : `No ${laneFilter === 'pals' ? 'Pals' : 'Match'} requests`}
          </AppText>
        </View>
      );
    }

    // If only received, show received list
    if (hasReceived && !hasSent) {
      return (
        <FlatList
          data={filteredIncomingRequests}
          keyExtractor={(item) => item.conversation_id}
          renderItem={({ item }) => (
            <RequestRow request={item} onPress={() => handleRequestPress(item.conversation_id)} />
          )}
          scrollEnabled={false}
        />
      );
    }

    // If only sent, show sent list
    if (!hasReceived && hasSent) {
      return (
        <FlatList
          data={filteredSentRequests}
          keyExtractor={(item) => item.conversation_id}
          renderItem={({ item }) => (
            <RequestRow
              request={{
                ...item,
                display_name: item.display_name,
                preview: 'Pending...',
              }}
              onPress={() => handleThreadPress(item.conversation_id)}
            />
          )}
          scrollEnabled={false}
        />
      );
    }

    // Both exist, show tabs and active list
    return (
      <>
        {renderRequestsSubTabs()}
        {requestsSubTab === 'received' ? (
          <FlatList
            data={filteredIncomingRequests}
            keyExtractor={(item) => item.conversation_id}
            renderItem={({ item }) => (
              <RequestRow request={item} onPress={() => handleRequestPress(item.conversation_id)} />
            )}
            scrollEnabled={false}
          />
        ) : (
          <FlatList
            data={filteredSentRequests}
            keyExtractor={(item) => item.conversation_id}
            renderItem={({ item }) => (
              <RequestRow
                request={{
                  ...item,
                  display_name: item.display_name,
                  preview: 'Pending...',
                }}
                onPress={() => handleThreadPress(item.conversation_id)}
              />
            )}
            scrollEnabled={false}
          />
        )}
      </>
    );
  };

  /**
   * Error banner (non-blocking)
   */
  const renderErrorBanner = () => {
    if (!error) return null;

    return (
      <View style={styles.errorBanner}>
        <AppText variant="caption" style={styles.errorText}>
          {error}
        </AppText>
        <TouchableOpacity onPress={() => setError(null)}>
          <AppText variant="caption" style={styles.errorDismiss}>
            Dismiss
          </AppText>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <ScreenContainer>
      {/* Top Lane Filter */}
      {renderLaneFilter()}

      {/* Error Banner */}
      {renderErrorBanner()}

      {/* Main Content */}
      {loading && !messagesHome ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={Colors.primary} />
          <AppText variant="caption" style={styles.loadingText}>
            Loading messages...
          </AppText>
        </View>
      ) : (
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} />}
          showsVerticalScrollIndicator={false}
        >
          {/* Matches Section */}
          {renderMatchesSection()}

          {/* Messages/Requests Tabs */}
          {renderTabs()}

          {/* Tab Content */}
          {activeTab === 'messages' ? renderMessagesContent() : renderRequestsContent()}
        </ScrollView>
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  // Lane filter (top segmented control)
  laneFilterContainer: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    gap: Spacing.sm,
    backgroundColor: Colors.background,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(31, 41, 55, 0.1)',
  },
  laneFilterButton: {
    flex: 1,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
    borderRadius: 20,
    backgroundColor: 'rgba(31, 41, 55, 0.05)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  laneFilterButtonActive: {
    backgroundColor: Colors.primary,
  },
  laneFilterText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.text,
    opacity: 0.7,
  },
  laneFilterTextActive: {
    color: Colors.background,
    opacity: 1,
  },

  // Error banner
  errorBanner: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#FEE2E2',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
  },
  errorText: {
    color: '#991B1B',
    flex: 1,
  },
  errorDismiss: {
    color: '#991B1B',
    fontWeight: '600',
  },

  // Loading state
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: Spacing.md,
  },
  loadingText: {
    opacity: 0.6,
  },

  // Scroll view
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: Spacing.xl,
  },

  // Sections
  section: {
    marginBottom: Spacing.lg,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: Spacing.md,
    paddingHorizontal: Spacing.lg,
  },

  // Matches
  matchesContent: {
    paddingHorizontal: Spacing.lg,
  },

  // Sub-tabs (for Requests)
  subTabsContainer: {
    flexDirection: 'row',
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm,
    gap: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(31, 41, 55, 0.1)',
    marginBottom: Spacing.sm,
  },
  subTab: {
    paddingVertical: Spacing.xs,
    paddingHorizontal: Spacing.md,
    borderRadius: 16,
    backgroundColor: 'rgba(31, 41, 55, 0.05)',
  },
  subTabActive: {
    backgroundColor: Colors.primary + '20',
  },
  subTabText: {
    fontSize: 13,
    fontWeight: '500',
    opacity: 0.7,
  },
  subTabTextActive: {
    opacity: 1,
    fontWeight: '600',
    color: Colors.primary,
  },

  // Tabs
  tabsContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(31, 41, 55, 0.1)',
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
  },
  tab: {
    flex: 1,
    paddingVertical: Spacing.md,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    borderBottomWidth: 2,
    borderBottomColor: 'transparent',
    gap: Spacing.xs,
  },
  tabActive: {
    borderBottomColor: Colors.primary,
  },
  tabText: {
    fontSize: 15,
    fontWeight: '500',
    opacity: 0.6,
  },
  tabTextActive: {
    opacity: 1,
    fontWeight: '700',
    color: Colors.primary,
  },
  badge: {
    backgroundColor: Colors.primary,
    borderRadius: 12,
    minWidth: 24,
    height: 24,
    paddingHorizontal: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    color: Colors.background,
    fontSize: 11,
    fontWeight: '700',
  },

  // Empty state
  emptyState: {
    paddingVertical: Spacing.xl * 2,
    paddingHorizontal: Spacing.xl,
    alignItems: 'center',
  },
  emptyStateText: {
    fontSize: 16,
    fontWeight: '600',
    opacity: 0.5,
    marginBottom: Spacing.sm,
  },
  emptyStateSubtext: {
    fontSize: 14,
    opacity: 0.4,
    textAlign: 'center',
  },
});
